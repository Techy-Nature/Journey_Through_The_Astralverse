# Twee Highlighting

Syntax highlighting for Twine **Twee 3** files (`.tw` and `.twee`), tuned for the **Duplex** story format and SugarCube-style markup.

Leans on **bold** and *italics*, with a mix of cool (blue, teal, sage) and warm (orange, tan, brown) colours. Separate palettes are used for dark and light editor themes.

## What gets highlighted

- Passage headers: `:: Name [tags] {"position":"…"}`. The name is bold, tags are italic.
- Macros: `<<set $x to 1>>`, `<<if …>>…<</if>>`. Macro names are bold, closing tags are bold italic, and keyword operators (`to`, `is`, `and`, `gte` …) are italic.
- Variables: story `$variables` are bold, `_temporaries` are italic.
- Links: `[[Text->Target]]`, `[[Target<-Text]]`, `[[Text|Target][$setter]]`. Link text is underlined and targets are italic.
- `''bold''` and `**bold**` render bold. Inside `[markdown]` passages and `<<markdown>>` blocks you also get headings, `*italic*`, lists, quotes and `code`.
- Comments: `// line` (at line start or after a space, like Duplex), `/* block */`, `<!-- html -->` and `<<comment>>…<</comment>>`.
- Button links: `{{button Label|Target}}`, `{{button Label->Target}}`, `{{button Target}}`, and the short forms `{{Label|Target}}`, `{{Label->Target}}`, `{{Target<-Label}}` and `{{Target}}`. The braces and the `button` word are bold, and the label and target look like a link.
- Skip and adult macros (`<<skipto>>`, `<<skipsummary>>`, `<<adult>>`, `<<notadult>>`) are bold italic orange so they stand out.
- Speech bubbles: in `<<speech>>` and `<<speaker>>`, keyed options (`fill`, `outline`, `text`, `name`, `portrait`) are bold and bare options (`shout`, `thought`, `pink`, `circle`, `right` …) are italic.
- Passage tags with meaning: `safe-room` is bold green, `unsafe-room`/`danger-room` are bold orange, and content tags such as `skip` or `violence` are orange italic.
- HTML tags and attributes.
- Real JavaScript/CSS highlighting (using your Acode theme's colours) in `Story JavaScript` / `[script]` passages, `Story Stylesheet` / `[stylesheet]` passages, `<<script>>` blocks, and `<script>` / `<style>` tags. `StoryData` is highlighted as JSON.

## Duplex mod files

Mod manifests are JSON. Name them `something.mod.json` (or `.duplexmod`) and they open as **Duplex Mod (JSON)**. For any other `.json` file, pick **Duplex Mod (JSON)** from the **⋮** menu under **Syntax highlighting**.

In a mod file, the manifest keys are bold. The Duplex markup inside `"content"` and `"text"` strings is highlighted like a passage, including macros, links, `{{button}}`, variables and HTML. `"room": "safe"` and `"unsafe"`, content tags, passage names and targets are styled to match the passage view.

## Plain-text .mod files (Duplex 1.9+)

Files ending in `.mod` or `.mod.txt` open as **Duplex Mod (.mod)**:

- The settings at the top (`Mod:`, `Version:`, `Author:`, `Description:`, `Story:`, `Requires:`) are bold, and the mod's name is bold too. `//` and `#` lines up there are comments.
- In `:: after Town Square` and `:: before Forest1`, the keyword is bold italic orange and the story passage name is italic.
- `:: place Name [tags]` and `:: Name [tags]` look like normal passage headers.
- The `:: items` section, and any section tagged `[items]` such as `:: Quest Items [items]`, is highlighted as JSON.
- `\::` at the start of a line is shown as an escape.

## Requirements

Acode 1.12.3 or newer.

## Known limits

- A line that starts with `::` always begins a new passage, even inside a stylesheet. Tweego reads it the same way, so write `*::selection` instead of `::selection` at the start of a CSS line.
